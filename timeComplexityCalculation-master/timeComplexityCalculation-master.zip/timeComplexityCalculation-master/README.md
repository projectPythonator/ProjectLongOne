#timeComplexityCalculation(hardvssimple)

end goal : to have a program that cam anylize simple arbitrary sections of code as well as trying to sort what makes an algorithm hard to calculate the time complexity vs what makes it easy

stage one
goal : this stage i will be trying to set up things for parsing lines of code. (this goal has already been done by other people before me)

stage two
goal : try to build a line between what makes an algorithm or piece of code hard to calculate in big o time complexity terms vs what would make it easy

stage four
goal : try to relate algorithms that are simple as well as complex and deal with them in the correct manner.

stage five
goal : test and implement.
